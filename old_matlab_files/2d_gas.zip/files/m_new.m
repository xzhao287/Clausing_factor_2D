function m_new
global newf
newf=true;