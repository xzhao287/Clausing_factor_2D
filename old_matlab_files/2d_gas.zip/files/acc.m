function acc
% set velocities to zeros;
global vx vy
vx=1.1*vx;
vy=1.1*vy;