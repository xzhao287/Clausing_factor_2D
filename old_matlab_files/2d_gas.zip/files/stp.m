function stp
% set velocities to zeros;
global vx vy
vx=0*vx;
vy=0*vy;