function buf
global fx hf
global hsl hslm xh yh th % hystory
set(hf,'WindowButtonMotionFcn','');
fx=0;

% clear hystory
xh=[];
yh=[];
th=[];
hsl=0;
