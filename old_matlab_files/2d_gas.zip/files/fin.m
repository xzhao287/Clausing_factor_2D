function fin

global stpf

stpf=true;