addpath([cd '\files\']);
gas; % start