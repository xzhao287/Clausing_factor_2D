function dec

global vx vy
vx=0.9*vx;
vy=0.9*vy;