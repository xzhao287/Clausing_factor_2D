function rnd_v
global n vx vy
vx=50*2*(rand(1,n)-0.5);
vy=50*2*(rand(1,n)-0.5);