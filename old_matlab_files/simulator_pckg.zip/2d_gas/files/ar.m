function ar

global vx vy
vx=0*vx+50*ones(size(vx));
vy=0*vy;