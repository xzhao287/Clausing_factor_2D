function au

global vx vy
vy=0*vy+50*ones(size(vy));
vx=0*vx;