addpath([cd 'D:\science_after_grad_school\1_kintics_gas_simulation\2d_gas']);
gas; % start